import tkinter as tk; root = tk.Tk(); root.title("Test"); root.mainloop()
